package com.example.aj

import android.os.Bundle
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import java.io.ByteArrayOutputStream


class Encode_Decode : Fragment() {
    lateinit var et: EditText
    lateinit var tt:TextView
    lateinit var en: Button
    lateinit var dn: Button
    lateinit var ee:TextView


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_encode__decode, container, false)
        et = view!!.findViewById(R.id.et)
        tt = view!!.findViewById(R.id.tt)
        en = view!!.findViewById(R.id.encode)
        dn = view!!.findViewById(R.id.decode)
        ee = view!!.findViewById(R.id.ee)
        return view
    }}
        //var e11=  et.getText()
/*en.setOnClickListener()
        {
            val stream:ByteArrayOutputStream= ByteArrayOutputStream()
            val bytes =stream.toByteArray()

            e11= Base64.encode(bytes,Base64.DEFAULT).toString()
            tt.setText(e11)
        }
        dn.setOnClickListener()
        {
             val de= Base64.decode(e11, Base64.DEFAULT)
            ee.setText(de.toString())

        }
        val data: ByteArray = e11.getBytes("UTF-8")
        val base64 = Base64.encodeToString(data, Base64.DEFAULT)
        val data = Base64.decode(base64, Base64.DEFAULT)
        val text = String(data, "UTF-8")

        return view

    }}*/
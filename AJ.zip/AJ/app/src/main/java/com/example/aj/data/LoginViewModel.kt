package com.example.aj.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.aj.data.Attendees
import com.example.aj.data.User
import com.example.aj.data.UserDatabase
import com.example.aj.data.UserRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LoginViewModel (application: Application): AndroidViewModel(application) {
     val repository: UserRepository
    var readAllData1: LiveData<List<Attendees>>
    init {
        val userDao = UserDatabase.getDatabase(application)?.userDao()
        repository = UserRepository(userDao!!)
        readAllData1=repository.readAllData1
    }

    fun addUser(user: User) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addUser(user)

        }
    }

    fun addUser1(user1: Attendees) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addUser1(user1)

        }
    }

    fun getUsername(userName: String): User {
      return repository.getUsername(userName)
    }

}
